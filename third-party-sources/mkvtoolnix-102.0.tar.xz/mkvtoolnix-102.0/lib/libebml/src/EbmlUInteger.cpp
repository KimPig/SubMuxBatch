// Copyright © 2002-2010 Steve Lhomme.
// SPDX-License-Identifier: LGPL-2.1-or-later

/*!
  \file
  \version \$Id$
  \author Steve Lhomme     <robux4 @ users.sf.net>
  \author Moritz Bunkus <moritz @ bunkus.org>
*/
#include <cassert>

#include "ebml/EbmlUInteger.h"

namespace libebml {

EbmlUInteger::EbmlUInteger()
  :EbmlElement(DEFAULT_UINT_SIZE, false)
{}

EbmlUInteger::EbmlUInteger(uint64 aDefaultValue)
  :EbmlElement(DEFAULT_UINT_SIZE, true), Value(aDefaultValue), DefaultValue(aDefaultValue)
{
  SetDefaultIsSet();
}

void EbmlUInteger::SetDefaultValue(uint64 aValue)
{
  assert(!DefaultISset());
  DefaultValue = aValue;
  SetDefaultIsSet();
}

uint64 EbmlUInteger::DefaultVal() const
{
  assert(DefaultISset());
  return DefaultValue;
}

EbmlUInteger::operator uint8()  const {return static_cast<uint8>(Value); }
EbmlUInteger::operator uint16() const {return static_cast<uint16>(Value);}
EbmlUInteger::operator uint32() const {return static_cast<uint32>(Value);}
EbmlUInteger::operator uint64() const {return Value;}

uint64 EbmlUInteger::GetValue() const {return Value;}

EbmlUInteger & EbmlUInteger::SetValue(uint64 NewValue) {
  return *this = NewValue;
}

/*!
  \todo handle exception on errors
*/
filepos_t EbmlUInteger::RenderData(IOCallback & output, bool /* bForceRender */, bool /* bWithDefault */)
{
  binary FinalData[8]; // we don't handle more than 64 bits integers

  if (GetSizeLength() > 8)
    return 0; // integer bigger coded on more than 64 bits are not supported

  uint64 TempValue = Value;
  for (unsigned int i=0; i<GetSize();i++) {
    FinalData[GetSize()-i-1] = TempValue & 0xFF;
    TempValue >>= 8;
  }

  output.writeFully(FinalData,GetSize());

  return GetSize();
}

uint64 EbmlUInteger::UpdateSize(bool bWithDefault, bool /* bForceRender */)
{
  if (!bWithDefault && IsDefaultValue())
    return 0;

  if (Value <= 0xFF) {
    SetSize_(1);
  } else if (Value <= 0xFFFF) {
    SetSize_(2);
  } else if (Value <= 0xFFFFFF) {
    SetSize_(3);
  } else if (Value <= 0xFFFFFFFF) {
    SetSize_(4);
  } else if (Value <= EBML_PRETTYLONGINT(0xFFFFFFFFFF)) {
    SetSize_(5);
  } else if (Value <= EBML_PRETTYLONGINT(0xFFFFFFFFFFFF)) {
    SetSize_(6);
  } else if (Value <= EBML_PRETTYLONGINT(0xFFFFFFFFFFFFFF)) {
    SetSize_(7);
  } else {
    SetSize_(8);
  }

  if (GetDefaultSize() > GetSize()) {
    SetSize_(GetDefaultSize());
  }

  return GetSize();
}

filepos_t EbmlUInteger::ReadData(IOCallback & input, ScopeMode ReadFully)
{
  if (ReadFully == SCOPE_NO_DATA)
    return GetSize();

  if (GetSize() > 8) {
    // impossible to read, skip it
    input.setFilePointer(GetSize(), seek_current);
    return GetSize();
  }

  binary Buffer[8];
  input.readFully(Buffer, GetSize());
  Value = 0;

  for (unsigned int i=0; i<GetSize(); i++) {
    Value <<= 8;
    Value |= Buffer[i];
  }
  SetValueIsSet();

  return GetSize();
}

bool EbmlUInteger::IsSmallerThan(const EbmlElement *Cmp) const
{
  if (EbmlId(*this) == EbmlId(*Cmp))
    return this->Value < static_cast<const EbmlUInteger *>(Cmp)->Value;

  return false;
}

} // namespace libebml
