// Copyright © 2002-2010 Steve Lhomme.
// SPDX-License-Identifier: LGPL-2.1-or-later

/*!
  \file
  \version \$Id$
  \author Steve Lhomme     <robux4 @ users.sf.net>
*/
#include <cassert>
#include <new>
#include <limits>

#include "ebml/EbmlString.h"

namespace libebml {

EbmlString::EbmlString()
  :EbmlElement(0, false)
{
  SetDefaultSize(0);
/* done automatically
  SetSize_(Value.length());
  if (GetDefaultSize() > GetSize())
    SetSize_(GetDefaultSize());*/
}

EbmlString::EbmlString(const std::string & aDefaultValue)
  :EbmlElement(0, true), Value(aDefaultValue), DefaultValue(aDefaultValue)
{
  SetDefaultSize(0);
  SetDefaultIsSet();
/* done automatically
  SetSize_(Value.length());
  if (GetDefaultSize() > GetSize())
    SetSize_(GetDefaultSize());*/
}

/*!
  \todo Cloning should be on the same exact type !
*/
void EbmlString::SetDefaultValue(std::string & aValue)
{
  assert(!DefaultISset());
  DefaultValue = aValue;
  SetDefaultIsSet();
}

const std::string & EbmlString::DefaultVal() const
{
  assert(DefaultISset());
  return DefaultValue;
}


/*!
  \todo handle exception on errors
*/
filepos_t EbmlString::RenderData(IOCallback & output, bool /* bForceRender */, bool /* bWithDefault */)
{
  filepos_t Result;
  output.writeFully(Value.c_str(), Value.length());
  Result = Value.length();

  if (Result < GetDefaultSize()) {
    // pad the rest with 0
    auto Pad = new (std::nothrow) binary[GetDefaultSize() - Result];
    if (Pad == nullptr) {
      return Result;
    }
    memset(Pad, 0x00, GetDefaultSize() - Result);
    output.writeFully(Pad, GetDefaultSize() - Result);
    Result = GetDefaultSize();
    delete [] Pad;
  }

  return Result;
}

EbmlString::operator const std::string &() const {return Value;}

EbmlString & EbmlString::operator=(const std::string & NewString)
{
  Value = NewString;
  SetValueIsSet();
/* done automatically
  SetSize_(Value.length());
  if (GetDefaultSize() > GetSize())
    SetSize_(GetDefaultSize());*/
  return *this;
}

EbmlString &EbmlString::SetValue(std::string const &NewValue) {
  return *this = NewValue;
}

std::string EbmlString::GetValue() const {
  return Value;
}

uint64 EbmlString::UpdateSize(bool bWithDefault, bool /* bForceRender */)
{
  if (!bWithDefault && IsDefaultValue())
    return 0;

  if (Value.length() < GetDefaultSize()) {
    SetSize_(GetDefaultSize());
  } else {
    SetSize_(Value.length());
  }
  return GetSize();
}

filepos_t EbmlString::ReadData(IOCallback & input, ScopeMode ReadFully)
{
  if (ReadFully == SCOPE_NO_DATA)
    return GetSize();

  if (GetSize() == 0) {
    Value.clear();

  } else {
    Value.resize(GetSize());
    std::memset(&Value[0], 0, GetSize());
    input.readFully(&Value[0], GetSize());

    auto PosNull = Value.find('\0');
    if (PosNull != std::string::npos)
      Value.resize(PosNull);
  }

  SetValueIsSet();

  return GetSize();
}

} // namespace libebml
