# LAPSE - Language-Agnostic subtitle synchronization engine
# Copyright (C) 2026 Rasmus Stisen Jensen (rs-jensen)
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

import json
import os
import queue
import sqlite3
import subprocess
import subs
import threading
import translate
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, "index.html")

config = {}
waiting = queue.Queue()


def db():
    conn = sqlite3.connect(config["db_path"], timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def setting(conn, key, fallback):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row[0] if row else fallback


def save_setting(conn, key, value):
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()


def folders():
    found = []
    for root in config["roots"]:
        found.append(root)
        try:
            names = sorted(os.listdir(root))
        except OSError:
            continue
        for name in names:
            path = os.path.join(root, name)
            if not name.startswith(".") and os.path.isdir(path):
                found.append(path)
    return found


def state():
    conn = db()
    rows = conn.execute(
        "SELECT id, video_path, srt_path, offset_ms, confidence, status, attempts,"
        " backup_path, created_at FROM sync_jobs ORDER BY id DESC LIMIT 2000"
    ).fetchall()

    counts = {}
    for status, total in conn.execute("SELECT status, COUNT(*) FROM sync_jobs GROUP BY status"):
        counts[status] = total

    versions = conn.execute(
        "SELECT id, source_path, output_path, language, provider, status, detail, created_at"
        " FROM translations ORDER BY id DESC LIMIT 2000"
    ).fetchall()

    answer = {
        "paused": setting(conn, "paused", "0") == "1",
        "translations": [dict(row) for row in versions],
        "translate": {
            "ready": translate.ready(),
            "provider": translate.PROVIDER,
            "targets": translate.TARGETS,
            "waiting": waiting.qsize(),
        },
        "engine": json.loads(setting(conn, "engine", "{}")),
        "count_embedded": setting(conn, "count_embedded", "0") == "1",
        "films": films(conn, setting(conn, "count_embedded", "0") == "1"),
        "interval": int(setting(conn, "scan_interval", config["interval"])),
        "excluded": json.loads(setting(conn, "excluded", "[]")),
        "folders": folders(),
        "roots": config["roots"],
        "counts": counts,
        "queued": config["jobs"].qsize(),
        "jobs": [dict(row) for row in rows],
    }
    conn.close()
    return answer


def undo(conn, ids):
    done = 0
    for job_id in ids:
        row = conn.execute("SELECT srt_path FROM sync_jobs WHERE id = ?", (job_id,)).fetchone()
        if not row:
            continue
        result = subprocess.run([config["lapse"], "--undo", row["srt_path"]],
                                capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            continue
        mtime = os.path.getmtime(row["srt_path"]) if os.path.exists(row["srt_path"]) else None
        conn.execute("UPDATE sync_jobs SET status = 'undone', backup_path = NULL, srt_mtime = ? WHERE id = ?",
                     (mtime, job_id))
        done += 1
    conn.commit()
    return done


def resync(conn, ids):
    if ids:
        marks = ",".join("?" * len(ids))
        rows = conn.execute("SELECT srt_path FROM sync_jobs WHERE id IN (%s)" % marks, ids).fetchall()
        conn.execute("DELETE FROM sync_jobs WHERE id IN (%s)" % marks, ids)
        directories = {os.path.dirname(row["srt_path"]) for row in rows}
    else:
        conn.execute("DELETE FROM sync_jobs")
        directories = set(config["roots"])
    conn.commit()

    for directory in directories:
        config["jobs"].put(directory)
    return len(directories)


def wanted_ids(body):
    return [int(value) for value in body.get("ids", [])]


def job(conn, job_id):
    return conn.execute(
        "SELECT id, video_path, srt_path, offset_ms, confidence FROM sync_jobs WHERE id = ?",
        (job_id,)
    ).fetchone()


def note_written(conn, row, path, offset, status="done"):
    conn.execute(
        "INSERT OR REPLACE INTO sync_jobs"
        " (video_path, srt_path, offset_ms, confidence, srt_mtime, attempts, status)"
        " VALUES (?, ?, ?, ?, ?, 1, ?)",
        (row["video_path"], path, offset, row["confidence"], os.path.getmtime(path), status)
    )


def output_mode(body):
    mode = body.get("output", "new")
    if mode not in ("new", "new_backup", "overwrite_backup", "overwrite"):
        raise RuntimeError("No such output mode: " + str(mode))
    return mode


def shift(conn, ids, ms, mode):
    if not ms:
        raise RuntimeError("Say how many milliseconds to move it by")

    for job_id in ids:
        row = job(conn, job_id)
        if not row:
            continue
        written = subs.shift(row["srt_path"], ms, mode)
        offset = (row["offset_ms"] or 0) + ms
        if written == row["srt_path"]:
            conn.execute("UPDATE sync_jobs SET offset_ms = ?, srt_mtime = ?, status = 'done' WHERE id = ?",
                         (offset, os.path.getmtime(written), job_id))
        else:
            note_written(conn, row, written, offset)
    conn.commit()


def engine_json(text):
    for line in reversed(text.splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                return json.loads(line)
            except ValueError:
                pass
    return {}


def inside_library(path):
    for root in config["roots"]:
        if path == root or path.startswith(root + os.sep):
            return True
    return False


def neighbours(conn, ids):
    found = []
    for job_id in ids:
        row = job(conn, job_id)
        if not row:
            continue
        folder = os.path.dirname(row["srt_path"])
        try:
            names = sorted(os.listdir(folder))
        except OSError:
            continue
        for name in names:
            if name.startswith("."):
                continue
            if os.path.splitext(name)[1].lower() in config["formats"]:
                full = os.path.join(folder, name)
                if full not in found:
                    found.append(full)
    found.sort()
    return found


def sync_one(conn, row, reference, mode):
    target = row["srt_path"]
    command = [config["lapse"], reference, target, "--json"]

    if mode.startswith("new"):
        base, ext = os.path.splitext(target)
        command = command + ["--output", base + ".synced" + ext]
    if mode == "new" or mode == "overwrite":
        command.append("--no-backup")

    result = subprocess.run(command, capture_output=True, text=True, timeout=600)
    values = engine_json(result.stdout or "")
    if not values:
        raise RuntimeError((result.stderr or "").strip() or "lapse said nothing")

    written = values.get("output") or target
    if not values.get("written") or not os.path.exists(written):
        conn.execute("UPDATE sync_jobs SET status = 'lowconf' WHERE id = ?", (row["id"],))
        return

    if values.get("verdict") == "solid":
        status = "done"
    else:
        status = "lowconf"

    if written == target:
        conn.execute(
            "UPDATE sync_jobs SET offset_ms = ?, confidence = ?, srt_mtime = ?, status = ? WHERE id = ?",
            (values.get("offset_ms"), values.get("sigma"),
             os.path.getmtime(written), status, row["id"])
        )
    elif mode.startswith("new"):
        note_written(conn, row, written, values.get("offset_ms"), status)
    else:
        conn.execute("UPDATE sync_jobs SET status = 'lowconf' WHERE id = ?", (row["id"],))


def reference_sync(conn, ids, reference, everything, mode):
    if not reference:
        raise RuntimeError("Say which subtitle is already correct")
    reference = os.path.normpath(reference)
    if not inside_library(reference) or not os.path.isfile(reference):
        raise RuntimeError("No such subtitle in the library: " + reference)

    if everything:
        folder = os.path.dirname(reference)
        ids = []
        for row in conn.execute("SELECT id, srt_path FROM sync_jobs"):
            if os.path.dirname(row["srt_path"]) == folder:
                ids.append(row["id"])

    for job_id in ids:
        row = job(conn, job_id)
        if row and row["srt_path"] != reference:
            sync_one(conn, row, reference, mode)
    conn.commit()


def convert(conn, ids, want, drop):
    for job_id in ids:
        row = job(conn, job_id)
        if not row:
            continue
        written = subs.convert(row["srt_path"], want, drop)
        note_written(conn, row, written, row["offset_ms"])
        if drop:
            conn.execute("DELETE FROM sync_jobs WHERE id = ?", (job_id,))
    conn.commit()


def films(conn, count_embedded):
    videos = {}
    for row in conn.execute("SELECT video_path, status FROM sync_jobs"):
        if row["video_path"] not in videos:
            videos[row["video_path"]] = []
        videos[row["video_path"]].append(row["status"])

    tracks = {}
    for row in conn.execute("SELECT video_path, tracks FROM video_tracks"):
        tracks[row["video_path"]] = row["tracks"]

    full = 0
    part = 0
    none = 0
    for video in videos:
        wanted = len(videos[video])
        if count_embedded:
            wanted = wanted + tracks.get(video, 0)
        ok = 0
        for status in videos[video]:
            if status == "done":
                ok = ok + 1
        if ok == 0:
            none = none + 1
        elif ok >= wanted:
            full = full + 1
        else:
            part = part + 1

    return {"total": len(videos), "full": full, "part": part, "none": none}


def queue_translations(conn, ids, language):
    if not language:
        raise RuntimeError("Say which language to translate into")
    if not translate.ready():
        raise RuntimeError("No translation provider is set up")
    if not ids:
        return 0

    marks = ",".join("?" * len(ids))
    rows = conn.execute("SELECT srt_path FROM sync_jobs WHERE id IN (%s)" % marks, ids).fetchall()
    for row in rows:
        source = row["srt_path"]
        output = translate.named(source, language)
        if translate.ours(conn, output) and os.path.exists(output):
            continue
        translate.remember(conn, source, output, language, "waiting", "")
        waiting.put((source, language))
    return len(rows)


def worker():
    while True:
        source, language = waiting.get()
        conn = db()
        try:
            translate.work(conn, source, language)
        except Exception as e:
            print("Translation worker:", e)
        finally:
            conn.close()


def act(path, body):
    conn = db()
    try:
        if path == "/api/preview":
            row = job(conn, int(body.get("id", 0)))
            if not row:
                raise RuntimeError("That file is not on record any more")
            return {"path": row["srt_path"], "cues": subs.preview(row["srt_path"])}
        elif path == "/api/shift":
            shift(conn, wanted_ids(body), int(body.get("ms", 0)), output_mode(body))
        elif path == "/api/neighbours":
            return {"paths": neighbours(conn, wanted_ids(body))}
        elif path == "/api/reference":
            reference_sync(conn, wanted_ids(body), (body.get("reference") or "").strip(),
                           bool(body.get("everything")), output_mode(body))
        elif path == "/api/convert":
            convert(conn, wanted_ids(body), (body.get("format") or "").lower(),
                    bool(body.get("drop")))
        elif path == "/api/embedded":
            save_setting(conn, "count_embedded", "1" if body.get("on") else "0")
        elif path == "/api/pause":
            hold = bool(body.get("paused"))
            save_setting(conn, "paused", "1" if hold else "0")
            if hold:
                config["halt"]()
        elif path == "/api/interval":
            save_setting(conn, "scan_interval", max(0, int(body.get("seconds", 0))))
        elif path == "/api/engine":
            saved = json.loads(setting(conn, "engine", "{}"))
            for key, value in (body.get("engine") or {}).items():
                if key in saved:
                    saved[key] = value
            save_setting(conn, "engine", json.dumps(saved))
        elif path == "/api/excluded":
            paths = [p.strip() for p in body.get("paths", []) if isinstance(p, str) and p.strip()]
            save_setting(conn, "excluded", json.dumps(sorted(set(paths))))
        elif path == "/api/undo":
            undo(conn, wanted_ids(body))
        elif path == "/api/resync":
            resync(conn, wanted_ids(body))
        elif path == "/api/translate":
            queue_translations(conn, wanted_ids(body), (body.get("language") or "").strip())
        elif path == "/api/scan":
            for root in config["roots"]:
                config["jobs"].put(root)
        else:
            return None
    finally:
        conn.close()
    return state()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def reply(self, payload, code=200):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.split("?")[0] == "/api/state":
            self.reply(state())
            return
        if self.path.split("?")[0] not in ("/", "/index.html"):
            self.reply({"error": "not found"}, 404)
            return
        with open(PAGE, "rb") as page:
            body = page.read()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            self.reply({"error": "that was not json"}, 400)
            return

        try:
            answer = act(self.path.split("?")[0], body)
        except Exception as e:
            self.reply({"error": str(e)}, 400)
            return

        if answer is None:
            self.reply({"error": "not found"}, 404)
        else:
            self.reply(answer)


def start(port, jobs, roots, db_path, lapse, interval, halt, formats):
    config.update({"jobs": jobs, "roots": roots, "db_path": db_path, "lapse": lapse,
                   "interval": interval, "halt": halt, "formats": formats})

    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    threading.Thread(target=worker, daemon=True).start()
    return server
